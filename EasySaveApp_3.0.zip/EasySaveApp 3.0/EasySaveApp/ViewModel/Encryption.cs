﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using EasySaveApp;

namespace EasySaveApp.ViewModel
{
    internal class Encryption
    {
        public class CryptoSoftFileEncryptor
        {
            private List<string> allowedExtensions;
            private string xorKey; // Clé pour le chiffrement XOR

            public CryptoSoftFileEncryptor(List<string> allowedExtensions, string xorKey)
            {
                this.allowedExtensions = allowedExtensions;
                this.xorKey = xorKey;
            }

            public void EncryptFilesInDirectory(string directoryPath)
            {
                var appConfig = AppConfig.Instance;

                // Get all files in the directory
                string[] files = Directory.GetFiles(directoryPath);

                foreach (string filePath in files)
                {
                    // If allowedExtensions is null or empty, or if the extension is allowed
                    if (allowedExtensions == null || !allowedExtensions.Any() || IsExtensionAllowed(filePath))
                    {
                        // Encrypt the file using XOR
                        EncryptFileWithXOR(filePath);

                        Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Fileencrypted"]);
                        Console.WriteLine(filePath);
                    }
                }
            }

            private void EncryptFileWithXOR(string filePath)
            {
                var appConfig = AppConfig.Instance;
                try
                {
                    byte[] fileBytes = File.ReadAllBytes(filePath);
                    byte[] keyBytes = Encoding.UTF8.GetBytes(xorKey);

                    for (int i = 0; i < fileBytes.Length; i++)
                    {
                        fileBytes[i] = (byte)(fileBytes[i] ^ keyBytes[i % keyBytes.Length]);
                    }

                    File.WriteAllBytes(filePath, fileBytes);


                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Fileencrypted"]);
                    Console.WriteLine(filePath);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["encryptionfail"]);
                    Console.WriteLine(ex.Message);
                }
            }

            private bool IsExtensionAllowed(string filePath)
            {
                string fileExtension = Path.GetExtension(filePath);
                return allowedExtensions.Contains(fileExtension, StringComparer.OrdinalIgnoreCase);
            }
        }
    }
}



