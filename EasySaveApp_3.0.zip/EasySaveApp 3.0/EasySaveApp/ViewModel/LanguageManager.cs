﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;


namespace EasySaveApp.ViewModel
{


    internal interface ILocalizationProvider
    {
        string GetLocalization(string key);
        void SetLanguage(string key);
    }

    public class LanguageManager : ILocalizationProvider
    {
        private Dictionary<string, Dictionary<string, string>> AllTranslations { get; set; }

        public LanguageManager(List<string> supportedLanguages, string defaultLanguage)
        {
            SupportedLanguages = supportedLanguages;
            CurrentLanguage = ValidateLanguage(defaultLanguage);
            LoadAllTranslations();
        }

        public string CurrentLanguage { get; private set; }
        public List<string> SupportedLanguages { get; private set; }

        public void SetLanguage(string language)
        {
            CurrentLanguage = ValidateLanguage(language);
        }

        private void LoadAllTranslations()
        {
            AllTranslations = new Dictionary<string, Dictionary<string, string>>();

            
        }

        public string GetLocalization(string key)
        {
            string currentLanguage = ValidateLanguage(CurrentLanguage);

            if (AllTranslations.TryGetValue(currentLanguage, out var languageData)
                && languageData.TryGetValue(key, out var localizedString))
            {
                return localizedString;
            }
            else
            {
                return key;
            }
        }

        private string ValidateLanguage(string language)
        {
            return SupportedLanguages.Contains(language) ? language : SupportedLanguages[0];
        }



    }

    public class ConsoleView
    {
        private readonly LanguageManager languageManager;

        public ConsoleView(LanguageManager languageManager)
        {
            this.languageManager = languageManager;
        }

        public void DisplayLabels(params string[] labelKeys)
        {
            foreach (var labelKey in labelKeys)
            {
                string translatedLabel = languageManager.GetLocalization(labelKey);
                Console.WriteLine(translatedLabel);
            }
        }
    }
    public class TranslationService
    {
        private Dictionary<string, Dictionary<string, string>> _translations;

        public TranslationService(string jsonPath)
        {
            LoadTranslations(jsonPath);
        }

        public string GetTranslation(string languageCode, string key)
        {
            if (_translations.TryGetValue(languageCode, out var languageTranslations))
            {
                if (languageTranslations.TryGetValue(key, out var translation))
                {
                    return translation;
                }
            }

            // Return an empty string if the translation is not found
            return string.Empty;
        }

        private void LoadTranslations(string jsonPath)
        {
            if (File.Exists(jsonPath))
            {
                string jsonContent = File.ReadAllText(jsonPath);
                _translations = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, string>>>(jsonContent);
            }
            else
            {
                // Handle the case where the JSON file is not found
                _translations = new Dictionary<string, Dictionary<string, string>>();
            }
        }
    }

}