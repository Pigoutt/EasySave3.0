﻿using EasySaveApp;
using EasySaveApp.Model;
using Microsoft.VisualBasic;
using System;
using System.Diagnostics.Metrics;
using System.Dynamic;
using System.IO;
using System.Net;
using System.Numerics;
using System.Text.Json;

namespace EasySaveApp.ViewModel
{
    
    public interface ILogManager
    {
        void LogBackupJob(BackupJob job);
    }
    
    internal class LogManager : ILogManager
    {


        public string logFilePath;
       
        public LogManager(string logDirectory)
        {
            var appConfig = AppConfig.Instance;
            if (!string.IsNullOrWhiteSpace(logDirectory))
            {
                // Assurez-vous que le chemin du répertoire de logs est valide
                if (!Directory.Exists(logDirectory))
                {
                    Directory.CreateDirectory(logDirectory);
                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["repertorycreate"]);
                }

                // Créez le chemin complet du fichier de logs

                logFilePath = Path.Combine(logDirectory, "backupLog.json");

                // Assurez-vous que le fichier de logs est correctement créé
                if (!File.Exists(logFilePath))
                {
                    // Créez le fichier de logs s'il n'existe pas
                    File.WriteAllText(logFilePath, "");
                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["logfilecreated"]);
                }
            }
        }

       
       

        public void LogBackupJob(BackupJob job)
        {
            var appConfig = AppConfig.Instance;
            try
            {


                logFilePath = "backupLog.json";

                if (!string.IsNullOrWhiteSpace(logFilePath))
                {
                    // Sérialisez l'objet BackupJob en une chaîne JSON
                    string serializedLogEntry = JsonSerializer.Serialize(job);

                    // Créez une entrée de journal formatée sur mesure (par exemple, avec une horodatage)
                    string formattedLogEntry = $"{DateTime.Now}: {serializedLogEntry}";

                    // Ajoutez la nouvelle entrée de journal au fichier existant
                    File.AppendAllText(logFilePath, formattedLogEntry + Environment.NewLine);

                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["journalok"]);
                }
                else
                {
                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["répertoirelogspasvalide"]);
                    Console.WriteLine(logFilePath);
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["echecjournal"]);
                Console.WriteLine(ex.Message);
                Console.WriteLine(logFilePath);
            }
        }
    }

}




