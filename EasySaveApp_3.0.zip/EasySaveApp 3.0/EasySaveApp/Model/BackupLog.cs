﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace EasySaveApp.Model
{
   public class BackupLog
    {
        public DateTime Timestamp { get; set; }
        public string jobName { get; set;}
        public string sourceAddress { get; set; }
        public string destinationAddress { get; set; }
        public long fileSize { get; set; }
        public int transfertTime { get; set; }
        public int Encryption{ get; set; }
        public BackupLog (DateTime timestamp, string JobName, string SourceAddress, string DestinationAddress, long FileSize, int TransfertTime, int encryption)
        {
            Timestamp = timestamp;
            jobName = JobName;
            sourceAddress = SourceAddress;
            destinationAddress = DestinationAddress;
            fileSize = FileSize;
            transfertTime = TransfertTime;
            Encryption = encryption;
        }
        public string ToJsonString()
        {
            return JsonSerializer.Serialize(this);
        }

    }
}
